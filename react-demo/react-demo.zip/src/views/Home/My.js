import React, { Component } from 'react'

export default class My extends Component {
    render() {
        return (
            <div>
                我的
            </div>
        )
    }
}
