import React, { Component } from 'react'

export default class VIP extends Component {
    render() {
        return (
            <div>
                订单
            </div>
        )
    }
}
